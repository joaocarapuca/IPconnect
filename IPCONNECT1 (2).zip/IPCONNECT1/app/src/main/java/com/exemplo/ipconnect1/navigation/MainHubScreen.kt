package com.exemplo.ipconnect1.navigation

class MainHubScreen {

}
