package com.example.ipconnect1.network

import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

// --- DATA CLASSES ---


data class User(
    val id: Int,
    val nome: String,
    val email: String,
    val cargo: String,
    val curso_id: Int?,
    val ano: Int?
)

data class LoginResponse(
    val status: String,
    val msg: String?,
    val user: User?
)

data class HorarioItem(
    val disciplina: String,
    val dia_semana: String,
    val hora_inicio: String,
    val sala: String
)

data class AlertaItem(
    val titulo: String,
    val mensagem: String,
    val data_alerta: String
)

data class MensagemItem(
    val id: Int,
    val id_remetente: Int,
    val nome_remetente: String,
    val conteudo: String,
    val data_envio: String
)

// Certifica-te que esta classe existe!
data class NotaItem(
    val disciplina: String,
    val valor_nota: Double,
    val data_lancamento: String
)

// --- INTERFACE API ---

interface ApiService {

    // Login e Registo
    @FormUrlEncoded
    @POST("php/login.php")
    suspend fun fazerLogin(
        @Field("email") email: String,
        @Field("senha") senha: String
    ): Response<LoginResponse>

    @FormUrlEncoded
    @POST("php/registo.php")
    suspend fun fazerRegisto(
        @Field("nome") nome: String,
        @Field("email") email: String,
        @Field("senha") senha: String,
        @Field("cargo") cargo: String,
        @Field("curso_id") cursoId: Int,
        @Field("ano") ano: Int
    ): Response<LoginResponse>

    // --- Notas aqui obter notas  ---
    @GET("php/get_notas.php")
    suspend fun obterNotas(@Query("aluno_id") alunoId: Int): List<NotaItem>
    // ---------------------------------------------------

    @GET("php/get_horario.php")
    suspend fun obterHorario(
        @Query("curso_id") cursoId: Int,
        @Query("ano") ano: Int
    ): List<HorarioItem>

    @GET("php/get_alertas.php")
    suspend fun obterAlertas(@Query("utilizador_id") userId: Int): List<AlertaItem>

    // Chat
    @GET("php/get_mensagens.php")
    suspend fun obterMensagens(@Query("id_user") userId: Int): List<MensagemItem>

    @FormUrlEncoded
    @POST("php/enviar_mensagem.php")
    suspend fun enviarMensagem(
        @Field("id_remetente") remetente: Int,
        @Field("id_destinatario") destinatario: Int,
        @Field("conteudo") conteudo: String
    ): Response<LoginResponse>
}

// --- CONFIGURAÇÃO CLIENTE ---

object RetrofitClient {
    private const val BASE_URL = "http://10.0.2.2/ipconnect_api/"

    val instance: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}