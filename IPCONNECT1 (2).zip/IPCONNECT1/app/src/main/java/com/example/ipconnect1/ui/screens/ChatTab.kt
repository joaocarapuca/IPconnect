package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ipconnect1.network.MensagemItem
import com.example.ipconnect1.network.RetrofitClient
import kotlinx.coroutines.launch
import com.example.ipconnect1.viewmodel.UserViewModel
@Composable
fun ChatTab(userViewModel: UserViewModel) {
    val user = userViewModel.loggedUser
    var mensagens by remember { mutableStateOf(emptyList<MensagemItem>()) }
    var novoTexto by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    // Função para carregar mensagens
    fun carregarMensagens() {
        scope.launch {
            try {
                if (user != null) {
                    mensagens = RetrofitClient.instance.obterMensagens(user.id)
                }
            } catch (e: Exception) { }
        }
    }

    LaunchedEffect(Unit) { carregarMensagens() }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mensagens", style = MaterialTheme.typography.headlineMedium, color = Color.Blue)

        // Lista de Mensagens
        LazyColumn(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
            items(mensagens) { msg ->
                val souEu = msg.id_remetente == user?.id

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (souEu) Alignment.End else Alignment.Start
                ) {
                    Surface(
                        color = if (souEu) Color(0xFFD1E3FF) else Color(0xFFE0E0E0),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(vertical = 4.dp).widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (!souEu) {
                                Text(text = msg.nome_remetente, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 12.sp)
                            }
                            Text(text = msg.conteudo)
                        }
                    }
                }
            }
        }

        // Campo para escrever
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = novoTexto,
                onValueChange = { novoTexto = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escreva uma mensagem...") }
            )
            IconButton(onClick = {
                if (novoTexto.isNotBlank() && user != null) {
                    scope.launch {
                        try {
                            // Exemplo: enviando para o ID 1 (ajustar conforme lógica)
                            val resp = RetrofitClient.instance.enviarMensagem(user.id, 1, novoTexto)
                            if (resp.isSuccessful) {
                                novoTexto = ""
                                carregarMensagens() // Atualiza a lista
                            }
                        } catch (e: Exception) { }
                    }
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.Blue)
            }
        }
    }
}