package com.example.ipconnect1.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ipconnect1.network.RetrofitClient
import kotlinx.coroutines.launch

@Composable
fun RegisterScreen(
    onNavigateToLogin: () -> Unit
) {
    // Contexto para mostrar Toasts (mensagens flutuantes)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // --- ESTADOS DOS CAMPOS ---
    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // Novos campos necessários
    var cursoId by remember { mutableStateOf("") } // O utilizador vai escrever o ID (ex: 1)
    var ano by remember { mutableStateOf("") }     // O utilizador vai escrever o Ano (ex: 1)

    // Estado de carregamento
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "CRIAR CONTA",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 1. Nome
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome Completo") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 2. Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Institucional") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 3. Password
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Palavra-passe") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 4. ID do Curso (Temporariamente manual)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedTextField(
                    value = cursoId,
                    onValueChange = { cursoId = it },
                    label = { Text("ID Curso (ex: 1)") },
                    modifier = Modifier.weight(1f).padding(end = 8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                // 5. Ano Curricular
                OutlinedTextField(
                    value = ano,
                    onValueChange = { ano = it },
                    label = { Text("Ano (1-3)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            // Mensagem de Erro
            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = Color.Red,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Botão Registar
            Button(
                onClick = {
                    // Validação simples
                    if (nome.isEmpty() || email.isEmpty() || password.isEmpty() || cursoId.isEmpty() || ano.isEmpty()) {
                        errorMessage = "Preenche todos os campos!"
                        return@Button
                    }

                    isLoading = true
                    errorMessage = null

                    scope.launch {
                        try {
                            // Converter os textos para números (segurança)
                            val cursoIdInt = cursoId.toIntOrNull() ?: 1
                            val anoInt = ano.toIntOrNull() ?: 1

                            // CHAMADA À API CORRIGIDA (com os 6 parâmetros)
                            val response = RetrofitClient.instance.fazerRegisto(
                                nome = nome,
                                email = email,
                                senha = password,
                                cargo = "aluno", // Padrão
                                cursoId = cursoIdInt, // <--- O que faltava
                                ano = anoInt          // <--- O que faltava
                            )

                            if (response.isSuccessful && response.body()?.status == "sucesso") {
                                Toast.makeText(context, "Conta criada! Faz login.", Toast.LENGTH_LONG).show()
                                onNavigateToLogin() // Vai para o Login
                            } else {
                                errorMessage = response.body()?.msg ?: "Erro ao registar."
                            }
                        } catch (e: Exception) {
                            errorMessage = "Erro de ligação: ${e.message}"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White)
                } else {
                    Text("REGISTAR")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = onNavigateToLogin) {
                Text("Já tens conta? Entrar")
            }
        }
    }
}