package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ipconnect1.viewmodel.UserViewModel

data class NavItem(
    val label: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainHub(userViewModel: UserViewModel, onLogout: () -> Unit) {
    var selectedItem by remember { mutableIntStateOf(0) }

    // Lista de 5 itens para a navegação
    val items = listOf(
        NavItem("Início", Icons.Default.Home),
        NavItem("Horário", Icons.Default.DateRange),
        NavItem("Perfil", Icons.Default.Person),

    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("IPConnect") },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index }
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(modifier = Modifier.padding(innerPadding)) {
            when (selectedItem) {
                0 -> HomeTab(userViewModel = userViewModel)
                1 -> ScheduleTab(userViewModel = userViewModel)
                2 -> ProfileTab(userViewModel = userViewModel, onLogout = onLogout)
            }
        }
    }
}