package com.example.ipconnect1.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ipconnect1.ui.screens.LoginScreen
import com.example.ipconnect1.ui.screens.RegisterScreen
import com.example.ipconnect1.ui.screens.MainHub
import com.example.ipconnect1.viewmodel.UserViewModel

@Composable
fun NavGraph(userViewModel: UserViewModel) { // <--- CORREÇÃO AQUI: Agora aceita o parâmetro

    val navController = rememberNavController()
    // A linha que criava o viewModel() aqui FOI REMOVIDA, porque já vem do MainActivity

    NavHost(navController = navController, startDestination = "login") {

        // Rota 1: Login
        composable("login") {
            LoginScreen(
                userViewModel = userViewModel,
                onNavigateToRegister = {
                    navController.navigate("register")
                },
                onLoginSuccess = {
                    navController.navigate("main") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }

        // Rota 2: Registo
        composable("register") {
            RegisterScreen(
                onNavigateToLogin = { // <--- Nome correto do parâmetro
                    navController.popBackStack()
                }
            )
        }

        // Rota 3: Principal
        composable("main") {
            MainHub(
                userViewModel = userViewModel,
                onLogout = {
                    navController.navigate("login") {
                        popUpTo("main") { inclusive = true }
                    }
                }
            )
        }
    }
}