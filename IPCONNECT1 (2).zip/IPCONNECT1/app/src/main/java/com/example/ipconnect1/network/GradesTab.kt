package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import  com.example.ipconnect1.viewmodel.UserViewModel
import com.example.ipconnect1.network.NotaItem
import com.example.ipconnect1.network.RetrofitClient

@Composable
fun GradesTab(userViewModel: UserViewModel) {
    val user = userViewModel.loggedUser
    var notas by remember { mutableStateOf(emptyList<NotaItem>()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    // Carregar as notas quando o ecrã abre
    LaunchedEffect(Unit) {
        try {
            if (user != null) {
                notas = RetrofitClient.instance.obterNotas(user.id)
            }
        } catch (e: Exception) {
            errorMsg = "Erro ao carregar notas"
        } finally {
            isLoading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "As Minhas Notas",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (errorMsg != null) {
            Text(text = errorMsg!!, color = Color.Red)
        } else if (notas.isEmpty()) {
            Text(text = "Ainda não tens notas lançadas.")
        } else {
            LazyColumn {
                items(notas) { nota ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = nota.disciplina,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Data: ${nota.data_lancamento}",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }

                            // Define a cor: >= 9.5 é verde, menos que isso é vermelho
                            val notaCor = if (nota.valor_nota >= 9.5) Color(0xFF2E7D32) else Color.Red

                            Text(
                                text = nota.valor_nota.toString(),
                                color = notaCor,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                        }
                    }
                }
            }
        }
    }
}