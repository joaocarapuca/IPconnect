package com.example.ipconnect1.ui.screens

class ProfileTab {
}