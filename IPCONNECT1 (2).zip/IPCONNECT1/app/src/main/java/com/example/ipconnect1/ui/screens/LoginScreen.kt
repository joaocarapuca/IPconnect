package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ipconnect1.network.RetrofitClient
import kotlinx.coroutines.launch
import com.example.ipconnect1.viewmodel.UserViewModel
@Composable
fun LoginScreen(
    userViewModel: UserViewModel,
    onNavigateToRegister: () -> Unit,
    onLoginSuccess: () -> Unit
) {
    // Estados para os campos de entrada
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    // Estados para controlo da interface
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Escopo para corrotinas (chamadas de rede)
    val scope = rememberCoroutineScope()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "IPCONNECT",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Blue
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Campo de Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Campo de Password
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Palavra-passe") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Exibe erro se os dados estiverem errados ou o XAMPP desligado
            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = Color.Red,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Botão de Login
            Button(
                onClick = {
                    isLoading = true
                    errorMessage = null

                    scope.launch {
                        try {
                            // Chamada ao teu ficheiro login.php
                            val response = RetrofitClient.instance.fazerLogin(email, password)

                            if (response.isSuccessful) {
                                val body = response.body()
                                if (body?.status == "sucesso" && body.user != null) {
                                    // SUCESSO: Guarda o utilizador no "cérebro" da App
                                    userViewModel.setUser(body.user)
                                    // Muda de ecrã
                                    onLoginSuccess()
                                } else {
                                    errorMessage = body?.msg ?: "Credenciais inválidas."
                                }
                            } else {
                                errorMessage = "Erro no servidor: ${response.code()}"
                            }
                        } catch (e: Exception) {
                            errorMessage = "Falha na ligação. O XAMPP está ligado?"
                        } finally {
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("ENTRAR")
                    }
                }


            }
        }
    }
