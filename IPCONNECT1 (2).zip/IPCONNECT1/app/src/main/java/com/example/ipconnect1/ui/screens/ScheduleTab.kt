package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ipconnect1.network.HorarioItem
import com.example.ipconnect1.network.RetrofitClient
import com.example.ipconnect1.viewmodel.UserViewModel

@Composable
fun ScheduleTab(userViewModel: UserViewModel) {
    val user = userViewModel.loggedUser
    var aulas by remember { mutableStateOf(emptyList<HorarioItem>()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Carregar dados assim que a aba abre
    LaunchedEffect(Unit) {
        try {
            if (user != null) {
                // CORREÇÃO AQUI: Enviamos curso_id e ano, em vez do user.id
                // Usamos o operador elvis (?: 1) para garantir que não vai nulo
                val cursoId = user.curso_id ?: 1
                val ano = user.ano ?: 1

                val response = RetrofitClient.instance.obterHorario(
                    cursoId = cursoId,
                    ano = ano
                )
                aulas = response
            }
        } catch (e: Exception) {
            errorMessage = "Erro ao carregar horário."
        } finally {
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Meu Horário",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (aulas.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (errorMessage != null) errorMessage!! else "Sem aulas marcadas para o teu ano.",
                    color = if (errorMessage != null) Color.Red else Color.Gray
                )
            }
        } else {
            LazyColumn {
                items(aulas) { aula ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = aula.disciplina,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = "${aula.dia_semana} | ${aula.hora_inicio}",
                                    color = Color.Gray
                                )
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = "SALA ${aula.sala}",
                                    modifier = Modifier.padding(8.dp),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}