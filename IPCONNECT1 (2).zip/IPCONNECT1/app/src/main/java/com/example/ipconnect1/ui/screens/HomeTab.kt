package com.example.ipconnect1.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ipconnect1.network.AlertaItem
import com.example.ipconnect1.network.RetrofitClient
import com.example.ipconnect1.viewmodel.UserViewModel
@Composable
fun HomeTab(userViewModel: UserViewModel) {
    val user = userViewModel.loggedUser
    // Estado para armazenar a lista de alertas que vem do PHP
    var alertas by remember { mutableStateOf(emptyList<AlertaItem>()) }
    var isLoading by remember { mutableStateOf(true) }

    // LaunchedEffect corre quando a aba é aberta
    LaunchedEffect(Unit) {
        try {
            if (user != null) {
                // Chama o get_alertas.php através do Retrofit
                val listaVindaDaApi = RetrofitClient.instance.obterAlertas(user.id)
                alertas = listaVindaDaApi
            }
        } catch (e: Exception) {
            // Se houver erro de rede, a lista fica vazia
        } finally {
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Alertas e AvisosSSSSSSS",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (alertas.isEmpty()) {
            Text(text = "Não existem avisos de momento.", modifier = Modifier.padding(8.dp))
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(alertas) { alerta ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = alerta.titulo,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Blue
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = alerta.mensagem,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Enviado em: ${alerta.data_alerta}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}