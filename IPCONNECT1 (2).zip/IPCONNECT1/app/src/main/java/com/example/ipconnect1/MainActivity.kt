package com.example.ipconnect1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ipconnect1.navigation.NavGraph
import com.example.ipconnect1.ui.theme.IPCONNECT1Theme
import com.example.ipconnect1.viewmodel.UserViewModel
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IPCONNECT1Theme {
                // Criamos o ViewModel que vai durar enquanto a app estiver aberta
                val userViewModel: UserViewModel = viewModel()

                // Chamamos o NavGraph passando o ViewModel
                NavGraph(userViewModel = userViewModel)
            }
        }
    }
}