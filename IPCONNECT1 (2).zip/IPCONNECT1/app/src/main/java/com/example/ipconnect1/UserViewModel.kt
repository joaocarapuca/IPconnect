package com.example.ipconnect1.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.ipconnect1.network.User

class UserViewModel : ViewModel() {
    // Aqui guardamos os dados do utilizador logado
    var loggedUser by mutableStateOf<User?>(null)
        private set

    fun setUser(user: User) {
        loggedUser = user
    }

    fun logout() {
        loggedUser = null
    }
}