package com.example.ipconnect1.navigation

class SetupNavGraph {

}
