<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conta Criada! - IPConnect</title>
    
    <link rel="stylesheet" href="../css/sucesso.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>

    <div class="success-card">
        <div class="icon-circle">
            <span class="material-icons-outlined big-icon">check_circle</span>
        </div>
        
        <h1>Parabéns!</h1>
        <p>A tua conta foi criada com sucesso.<br>
        Já podes descarregar a aplicação e entrar no mundo <b>IPConnect</b>.</p>
        
        <div class="btn-group">
            <a href="pagina_login.php" class="btn-login">Ir para o Login</a>
            
            <a href="#" class="btn-download" onclick="alert('O download da App para Android iniciará em breve!')">
                <span class="material-icons-outlined">android</span>
                Descarregar App Android
            </a>
        </div>
        
        <p style="margin-top: 30px; font-size: 0.9rem; color: #888;">
            A voltar ao início em <span id="contador" style="font-weight:bold; color:#43e97b;">5</span> segundos...
        </p>
    </div>

    <script>
        // Define o tempo inicial
        let segundos = 5;
        
        // Função que corre a cada 1 segundo (1000 milissegundos)
        const intervalo = setInterval(function() {
            segundos--; // Diminui 1 segundo
            
            // Atualiza o número no ecrã
            document.getElementById('contador').innerText = segundos;
            
            // Se chegar ao zero, muda de página
            if (segundos <= 0) {
                clearInterval(intervalo); // Para o relógio
                window.location.href = '../index.html'; // Redireciona para a raiz
            }
        }, 1000);
    </script>

</body>
</html>