<?php
// Vai buscar a configuração que está na pasta ao lado 'php'
include '../php/config.php';


// Listagem de cursos para selecionar
$cursos_query = $conn->query("SELECT * FROM cursos");
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta - IPConnect</title>
    
    <link rel="stylesheet" href="../css/criar_conta.css"> 
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>

    <div class="form-container">
        <div class="logo-text">
            IP<span style="color: #4facfe;">Connect</span>
        </div>
        
        <h2>Criar Conta</h2>
        <p style="margin-bottom: 30px; color: #888; font-size: 0.95rem;">
            Preenche os dados para acederes à App.
        </p>

        <form action="../php/registo.php" method="POST">
            
            <div class="input-group">
                <label for="nome">Nome Completo</label>
                <input type="text" id="nome" name="nome" placeholder="Ex: Ana Santos" required>
            </div>

            <div class="input-group">
                <label for="email">Email Institucional</label>
                <input type="email" id="email" name="email" placeholder="aluno@ip.pt" required>
            </div>

            <div class="input-group">
                <label for="senha">Palavra-passe</label>
                <input type="password" id="senha" name="senha" placeholder="••••••••" required>
            </div>

            <div class="input-group">
                <label for="curso">O meu Curso</label>
                <select name="curso_id" id="curso" required>
                    <option value="">Selecione o Curso</option>
                    <?php 
                    if(isset($cursos_query) && $cursos_query){
                        while($c = $cursos_query->fetch_assoc()): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo $c['nome']; ?></option>
                        <?php endwhile; 
                    } ?>
                </select>
            </div>

            <div class="input-group">
                <label for="ano">Ano Curricular</label>
                <select name="ano" id="ano" required>
                    <option value="">Selecione o Ano</option>
                    <option value="1">1º Ano</option>
                    <option value="2">2º Ano</option>
                    <option value="3">3º Ano</option>
                </select>
            </div>
            <div class="input-group">
                <label for="cargo">Eu sou:</label>
                <select name="cargo" id="cargo">
                    <option value="aluno">Aluno</option>
                    <option value="professor">Professor</option>
                </select>
            </div>

            <input type="hidden" name="web" value="true">

            <button type="submit" class="btn-full">Registar Agora</button>
        </form>

        <div class="login-link">
            Já tens conta? <a href="../index.html">Voltar ao Início</a>
        </div>
    </div>

</body>
</html>