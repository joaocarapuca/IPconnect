<?php
include '../php/config.php';
session_start();
if (!isset($_SESSION['admin_id'])) { header("Location: pagina_login.php"); exit; }

// Buscas na Base de Dados
//implentar icon para deixar isto mais dinamico 
$total_users = $conn->query("SELECT COUNT(*) as total FROM utilizadores")->fetch_assoc()['total'];
$total_aulas = $conn->query("SELECT COUNT(*) as total FROM horarios")->fetch_assoc()['total'];

$horarios = $conn->query("SELECT h.*, c.nome as curso FROM horarios h JOIN cursos c ON h.curso_id = c.id ORDER BY h.id DESC LIMIT 5");
$todos_users = $conn->query("SELECT id, nome, email FROM utilizadores ORDER BY nome ASC");
$cursos = $conn->query("SELECT * FROM cursos");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Gestão IPConnect</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>

<div class="dashboard-container">
    <aside class="sidebar">
        <h2>IP<span style="color:var(--secondary)">Connect</span></h2>
        <a href="admin_panel.php" class="nav-item active"><span class="material-icons-outlined">dashboard</span> Dashboard</a>
        <a href="#section-create-horario" class="nav-item"><span class="material-icons-outlined">calendar_today</span> Horários</a>
        <a href="#section-users" class="nav-item"><span class="material-icons-outlined">people</span> Utilizadores</a>
        <a href="#section-alertas" class="nav-item"><span class="material-icons-outlined">notifications</span> Alertas</a>
        <div style="margin-top:auto;">
            <a href="../php/logout.php" class="nav-item" style="color:var(--danger);">
                <span class="material-icons-outlined">logout</span> Sair
            </a>
        </div>
    </aside>

    <main class="main-content">
        <div class="header-stats">
            <div class="stat-card">
                <div class="label">Utilizadores</div>
                <div class="value"><?php echo $total_users; ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Aulas</div>
                <div class="value"><?php echo $total_aulas; ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Status Sistema</div>
                <div class="value" style="color:var(--primary); font-size:1.2rem;">Online</div>
            </div>
        </div>

        <div class="content-grid" style="margin-bottom: 30px;">
            <div class="panel" id="section-create-horario">
                <h3>📅 Criar Novo Horário</h3>
                <form action="../php/admin_actions.php" method="POST">
                    <div class="grid-inputs">
                        <div class="form-group">
                            <label>Curso</label>
                            <select name="curso_id" required>
                                <?php while($c = $cursos->fetch_assoc()): ?>
                                    <option value="<?php echo $c['id']; ?>"><?php echo $c['nome']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Ano</label>
                            <select name="ano" required>
                                <option value="1">1º Ano</option>
                                <option value="2">2º Ano</option>
                                <option value="3">3º Ano</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Disciplina</label>
                        <input type="text" name="disciplina" placeholder="Ex: Matemática Aplicada" required>
                    </div>
                    <div class="grid-inputs">
                        <div class="form-group">
                            <label>Dia</label>
                            <select name="dia" required>
                                <option>Segunda</option><option>Terça</option><option>Quarta</option><option>Quinta</option><option>Sexta</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Sala</label>
                            <input type="text" name="sala" placeholder="Ex: B201" required>
                        </div>
                    </div>
                    <div class="grid-inputs">
                        <div class="form-group"><label>Início</label><input type="time" name="hora_inicio" required></div>
                        <div class="form-group"><label>Fim</label><input type="time" name="hora_fim" required></div>
                    </div>
                    <button type="submit" name="add_horario" class="btn-submit">Publicar Horário</button>
                </form>
            </div>

            <div class="panel" id="section-alertas">
                <h3>📢 Enviar Alerta Geral</h3>
                <p style="font-size:0.8rem; color:#64748b; margin-bottom:15px;">Esta mensagem aparecerá no feed de todos os alunos.</p>
                <form action="../php/admin_actions.php" method="POST">
                    <div class="form-group">
                        <label>Título do Alerta</label>
                        <input type="text" name="titulo" placeholder="Ex: Alteração de Sala" required>
                    </div>
                    <div class="form-group">
                        <label>Mensagem</label>
                        <textarea name="mensagem" rows="5" placeholder="Escreve aqui o aviso importante..." required></textarea>
                    </div>
                    <button type="submit" name="criar_alerta" class="btn-submit">Enviar Notificação</button>
                </form>
            </div>
        </div>

        <div class="panel" id="section-users">
            <h3>Gestão de Utilizadores</h3>
            <p style="font-size:0.85rem; color:#64748b; margin-bottom:20px;">Altera credenciais ou remove contas de utilizadores.</p>
            
            <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap:15px; margin-top:15px;">
                <?php $todos_users->data_seek(0); while($u = $todos_users->fetch_assoc()): ?>
                <div class="user-row" style="display:flex; justify-content:space-between; align-items:center; cursor:default;">
                    <div class="user-info">
                        <b><?php echo $u['nome']; ?></b><br>
                        <span style="font-size:0.85rem; color:#64748b;"><?php echo $u['email']; ?></span>
                    </div>
                    
                    <div style="display:flex; gap:10px;">
                        <button type="button" onclick="abrirModal('<?php echo $u['id']; ?>', '<?php echo $u['nome']; ?>')" 
                                style="background:#f0f7ff; border:none; border-radius:8px; padding:8px; cursor:pointer; color:var(--secondary); display:flex;">
                            <span class="material-icons-outlined">vpn_key</span>
                        </button>

                        <a href="../php/admin_actions.php?delete_user=<?php echo $u['id']; ?>" 
                           onclick="return confirm('Tens a certeza que queres apagar este utilizador permanentemente?')"
                           style="background:#fff1f2; border:none; border-radius:8px; padding:8px; cursor:pointer; color:#f43f5e; display:flex; text-decoration:none;">
                            <span class="material-icons-outlined">delete_outline</span>
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </main>
</div>

<div id="modalPass" class="modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
    <div class="modal-content" style="background:white; padding:30px; border-radius:15px; width:90%; max-width:400px; box-shadow:0 10px 25px rgba(0,0,0,0.2);">
        <h3 style="margin-top:0;">🔐 Nova Senha</h3>
        <p>Alterar a senha de: <b id="nomeUserModal" style="color:var(--secondary)"></b></p>
        
        <form action="../php/admin_actions.php" method="POST">
            <input type="hidden" name="id_user" id="idUserModal">
            
            <div style="margin-bottom:15px;">
                <input type="password" name="nova_senha" required placeholder="Digite a nova senha" 
                       style="width:100%; padding:12px; border:1px solid #ccc; border-radius:8px; box-sizing:border-box;">
            </div>

            <div style="display:flex; gap:10px;">
                <button type="button" onclick="fecharModal()" 
                        style="flex:1; padding:12px; border:none; background:#f1f5f9; color:#333; border-radius:8px; cursor:pointer; font-weight:600;">
                    Cancelar
                </button>
                <button type="submit" name="alterar_senha_user" 
                        style="flex:1; padding:12px; border:none; background:#4facfe; color:white; border-radius:8px; cursor:pointer; font-weight:600;">
                    Gravar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Função para ABRIR o Modal
    function abrirModal(id, nome) {
        document.getElementById('idUserModal').value = id;
        document.getElementById('nomeUserModal').innerText = nome;
        document.getElementById('modalPass').style.display = 'flex';
    }

    // Função para FECHAR o Modal
    function fecharModal() {
        document.getElementById('modalPass').style.display = 'none';
    }

    // Fechar se clicar fora da janela branca
    window.onclick = function(event) {
        var modal = document.getElementById('modalPass');
        if (event.target == modal) {
            fecharModal();
        }
    }
</script>

</body>
</html>