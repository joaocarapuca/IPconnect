<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar - IPConnect</title>
    
    <link rel="stylesheet" href="../css/login.css"> 
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
</head>
<body>

    <div class="form-container">
        <div class="logo-text">
            IP<span style="color: #4facfe;">Connect</span>
        </div>
        
        <h2 style="color:#333; margin-bottom: 5px;">Bem-vindo de volta!</h2>
        <p style="color:#888; margin-bottom: 30px;">Introduz as tuas credenciais.</p>

        <form action="../php/login.php" method="POST">
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="teu@email.com" required>
            </div>

            <div class="input-group">
                <label for="senha">Palavra-passe</label>
                <input type="password" id="senha" name="senha" placeholder="••••••••" required>
            </div>

            <input type="hidden" name="web" value="true">

            <button type="submit" class="btn-full">Entrar</button>
        </form>
        
        <div class="links">
            <a href="../index.html">Voltar ao Início</a> | <a href="criar_conta.php">Criar Conta</a>
        </div>
    </div>

</body>
</html>