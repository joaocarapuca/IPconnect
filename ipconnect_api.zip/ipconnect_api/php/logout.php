<?php
session_start();
session_unset();
session_destroy();

// Como o logout está em /php e o index na raiz, usamos ../ para subir um nível
header("Location: ../index.html");
exit();
?>