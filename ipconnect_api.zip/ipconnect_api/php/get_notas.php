<?php
include 'config.php';

// Recebe o ID do aluno
$aluno_id = isset($_GET['aluno_id']) ? (int)$_GET['aluno_id'] : 0;

// Busca as notas desse aluno
$sql = "SELECT disciplina, valor_nota, data_lancamento FROM notas WHERE aluno_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $aluno_id);
$stmt->execute();
$result = $stmt->get_result();

$notas = [];

while($row = $result->fetch_assoc()) {
    $notas[] = $row;
}

// Devolve em JSON para o Android
header('Content-Type: application/json');
echo json_encode($notas);
?>