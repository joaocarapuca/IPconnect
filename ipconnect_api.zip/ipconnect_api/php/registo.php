<?php
// Inclui o config (ambos estão na pasta php)
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. Receber os dados do formulário
    $nome  = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');
    $cargo = trim($_POST['cargo'] ?? 'aluno');
    $curso_id = isset($_POST['curso_id']) ? (int)$_POST['curso_id'] : NULL;
    $ano      = isset($_POST['ano']) ? (int)$_POST['ano'] : NULL;
    
    // Verifica se o pedido veio do Website (campo hidden)
    $isWeb = isset($_POST['web']);

    // 2. Verificar se o email já existe
    $check = $conn->query("SELECT id FROM utilizadores WHERE email = '$email'");
    if ($check->num_rows > 0) {
        if ($isWeb) { 
            echo "<script>alert('Erro: Este email já está registado!'); window.history.back();</script>"; 
        } else { 
            echo json_encode(["status" => "erro", "msg" => "Email já existe"]); 
        }
        exit;
    }

    // 3. Inserir na Base de Dados
    $stmt = $conn->prepare("INSERT INTO utilizadores (nome, email, senha, cargo, curso_id, ano) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssii", $nome, $email, $senha, $cargo, $curso_id, $ano);

    if ($stmt->execute()) {
        // --- SUCESSO ---
        if ($isWeb) {
            header('Content-Type: text/html; charset=utf-8');
            // Redireciona para a página bonita na pasta HTML
            echo "<script>
                window.location.href = '../html/sucesso.php'; 
            </script>";
        } else {
            // Se for pela App Android
            echo json_encode(["status" => "sucesso", "msg" => "Registado com sucesso"]);
        }
    } else {
        // --- ERRO ---
        if ($isWeb) { 
            echo "<script>alert('Erro no sistema.'); window.history.back();</script>"; 
        } else { 
            echo json_encode(["status" => "erro", "msg" => "Erro ao inserir"]); 
        }
    }
}
?>