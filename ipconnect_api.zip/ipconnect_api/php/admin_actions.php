<?php
include 'config.php';
session_start();

// Verifica se é admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../html/pagina_login.php");
    exit;
}

$msg = "";

// --- 1. ADICIONAR HORÁRIO (CORRIGIDO) ---
if (isset($_POST['add_horario'])) {
    // Receber dados do formulário
    $curso_id   = $_POST['curso_id'];
    $ano        = $_POST['ano'];
    $disciplina = $_POST['disciplina'];
    $dia        = $_POST['dia'];
    $sala       = $_POST['sala'];
    $inicio     = $_POST['hora_inicio'];
    $fim        = $_POST['hora_fim'];

    // SQL Corrigido: 7 Colunas para 7 Variáveis
    $stmt = $conn->prepare("INSERT INTO horarios (curso_id, ano, disciplina, dia, sala, hora_inicio, hora_fim) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    // Verifica se a preparação funcionou
    if ($stmt === false) {
        die("Erro no SQL Horários: " . $conn->error);
    }

    // Bind Corrigido: Ordem exata das colunas acima
    // i=inteiro, s=string
    $stmt->bind_param("iisssss", $curso_id, $ano, $disciplina, $dia, $sala, $inicio, $fim);
    
    if($stmt->execute()) { 
        $msg = "sucesso_horario"; 
    } else { 
        $msg = "erro_horario: " . $stmt->error; 
    }
}

// --- 2. ENVIAR ALERTA ---
if (isset($_POST['criar_alerta'])) {
    $titulo = $_POST['titulo'];
    $mensagem = $_POST['mensagem'];
    // Removi utilizador_id para garantir compatibilidade com a tabela simples
    // Se a tua tabela alertas tiver utilizador_id, descomenta a linha abaixo e ajusta o SQL
    // $id_admin = $_SESSION['admin_id'];

    $stmt = $conn->prepare("INSERT INTO alertas (titulo, mensagem) VALUES (?, ?)");
    $stmt->bind_param("ss", $titulo, $mensagem);
    
    if($stmt->execute()) { 
        $msg = "sucesso_alerta"; 
    } else {
        $msg = "erro_alerta";
    }
}

// --- 3. CRIAR POST (Se a tabela existir) ---
if (isset($_POST['criar_post'])) {
    $imagem = $_POST['imagem_url'];
    $legenda = $_POST['legenda'];

    $stmt = $conn->prepare("INSERT INTO posts (imagem_url, legenda) VALUES (?, ?)");
    if ($stmt) {
        $stmt->bind_param("ss", $imagem, $legenda);
        if($stmt->execute()) { $msg = "sucesso_post"; }
    }
}

// --- 4. ALTERAR SENHA DE UTILIZADOR ---
if (isset($_POST['alterar_senha_user'])) {
    $id_user = $_POST['id_user'];
    $nova_senha = $_POST['nova_senha']; // Em produção, devias usar password_hash()

    $stmt = $conn->prepare("UPDATE utilizadores SET senha = ? WHERE id = ?");
    $stmt->bind_param("si", $nova_senha, $id_user);

    if($stmt->execute()) { $msg = "sucesso_senha"; } else { $msg = "erro"; }
}

// --- 5. APAGAR UTILIZADOR ---
if (isset($_GET['delete_user'])) {
    $id = (int)$_GET['delete_user'];
    
    // Evita que o admin se apague a si próprio (session_start já foi iniciado no topo)
    if($id == $_SESSION['admin_id']) {
        header("Location: ../html/admin_panel.php?msg=erro_self");
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM utilizadores WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if($stmt->execute()) {
        header("Location: ../html/admin_panel.php?msg=apagado");
    } else {
        header("Location: ../html/admin_panel.php?msg=erro");
    }
    exit;
}

// --- 6. APAGAR HORÁRIO (CORRIGIDO & SEGURO) ---
if (isset($_GET['delete_horario'])) {
    $id = (int)$_GET['delete_horario'];
    
    $stmt = $conn->prepare("DELETE FROM horarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if($stmt->execute()) {
        $msg = "horario_apagado";
    } else {
        $msg = "erro_apagar_horario";
    }
}

// Redirecionamento final
header("Location: ../html/admin_panel.php?msg=" . $msg);
exit;
?>