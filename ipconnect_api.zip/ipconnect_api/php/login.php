<?php
include 'config.php';
session_start(); // OBRIGATÓRIO: Inicia a memória do site

// Recebe dados (com proteção básica se não existirem)
$email = isset($_POST['email']) ? $_POST['email'] : '';
$senha = isset($_POST['senha']) ? $_POST['senha'] : '';

$response = array();

// Verifica na base de dados
$sql = "SELECT * FROM utilizadores WHERE email = ? AND senha = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $senha);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // ======================================================
    // 🔴 1. SE FOR O SITE (WEB)
    // O PHP procura aquele input "hidden" que meteste no HTML
    // ======================================================
    if (isset($_POST['web']) && $_POST['web'] == 'true') {
        
        // Guarda quem entrou na memória do navegador
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_nome'] = $row['nome'];
        $_SESSION['cargo'] = $row['cargo'];

        // Redireciona para o sítio certo
        if ($row['cargo'] == 'admin') {
            header("Location: ../html/admin_panel.php");
        } else {
            header("Location: ../index.html"); 
        }
        exit; // 🛑 PÁRA AQUI! Não deixa o código continuar para o JSON
    }

    // ======================================================
    // 🟢 2. SE FOR A APP ANDROID
    // Se não encontrou o campo "web", assume que é a App
    // ======================================================
    header('Content-Type: application/json; charset=utf-8');
    
    $response['status'] = 'sucesso';
    $response['user'] = array(
        'id' => (int)$row['id'],
        'nome' => $row['nome'],
        'email' => $row['email'],
        'cargo' => $row['cargo'],
        'curso_id' => $row['curso_id'] ? (int)$row['curso_id'] : 1,
        'ano' => $row['ano'] ? (int)$row['ano'] : 1
    );

} else {
    // --- LOGIN FALHOU ---

    // Se for Site: volta para o login com erro na URL
    if (isset($_POST['web']) && $_POST['web'] == 'true') {
        header("Location: ../html/pagina_login.php?erro=1");
        exit;
    } 
    
    // Se for App: envia JSON de erro
    else {
        header('Content-Type: application/json; charset=utf-8');
        $response['status'] = 'erro';
        $response['msg'] = 'Email ou senha incorretos.';
    }
}

// Imprime o JSON (só chega aqui se for a App)
echo json_encode($response);
?>