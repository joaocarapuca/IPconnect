<?php
include 'config.php';

// Define que a resposta é JSON (importante para o Android não dar erro)
header('Content-Type: application/json; charset=utf-8');

//aqui usei  'dia AS dia_semana' para enganar a App
// Assim a App recebe o que espera, mesmo que na BD se chame 'dia problema com a bd'
$sql = "SELECT 
            h.id,
            c.nome as curso, 
            h.ano, 
            h.disciplina, 
            h.dia AS dia_semana,  
            h.sala, 
            h.hora_inicio, 
            h.hora_fim 
        FROM horarios h 
        JOIN cursos c ON h.curso_id = c.id 
        ORDER BY h.dia, h.hora_inicio";

$result = $conn->query($sql);

$response = array();

if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Formatar as horas para ficarem bonitas (ex: 14:30 em vez de 14:30:00)
        $row['hora_inicio'] = date('H:i', strtotime($row['hora_inicio']));
        $row['hora_fim'] = date('H:i', strtotime($row['hora_fim']));
        
        array_push($response, $row);
    }
    // Envia o JSON limpo
    echo json_encode($response);
} else {
    // Se der erro, envia um JSON vazio ou mensagem
    echo json_encode(null);
}
?>