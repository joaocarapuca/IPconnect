<?php
include 'config.php';

$utilizador_id = $_GET['utilizador_id'] ?? 0;

$sql = "SELECT titulo, mensagem, data_alerta 
        FROM alertas 
        WHERE utilizador_id = ? 
        ORDER BY data_alerta DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $utilizador_id);
$stmt->execute();
$result = $stmt->get_result();

$alertas = [];
while($row = $result->fetch_assoc()) {
    $alertas[] = $row;
}

echo json_encode($alertas);
?>