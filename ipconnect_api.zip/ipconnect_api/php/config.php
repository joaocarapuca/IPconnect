<?php
// Configurações da Base de Dados (XAMPP Padrão)
$servername = "localhost";
$username = "root";       // Utilizador padrão do XAMPP
$password = "";           // Senha padrão do XAMPP (vazia)
$dbname = "ipconnect_db"; // Nome da tua base de dados

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die("Falha na conexão com a base de dados: " . $conn->connect_error);
}

// Forçar a codificação UTF-8 (para aceitar acentos e 'ç')
$conn->set_charset("utf8");
?>