<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>IPConnect - Portal Web</title>
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: space-around; padding: 50px; background: #f4f4f4; }
        .card { background: white; padding: 20px; border-radius: 8px; shadow: 0 2px 5px rgba(0,0,0,0.1); width: 300px; }
        input, select, button { width: 100%; margin: 10px 0; padding: 10px; }
        button { background: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>

    <div class="card">
        <h2>Criar Conta</h2>
        <form action="registo.php" method="POST">
            <input type="text" name="nome" placeholder="Nome Completo" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="senha" placeholder="Palavra-passe" required>
            <select name="cargo">
                <option value="aluno">Aluno</option>
                <option value="professor">Professor</option>
            </select>
            <input type="hidden" name="web" value="true"> <button type="submit">Registar</button>
        </form>
    </div>

    <div class="card">
        <h2>Entrar</h2>
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="senha" placeholder="Palavra-passe" required>
            <input type="hidden" name="web" value="true">
            <button type="submit">Login</button>
        </form>
    </div>

</body>
</html>