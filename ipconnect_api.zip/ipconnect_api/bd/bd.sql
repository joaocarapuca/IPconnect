-- Tabela de Cursos
CREATE TABLE cursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Tabela de Utilizadores
CREATE TABLE utilizadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    cargo ENUM('aluno', 'admin') DEFAULT 'aluno',
    curso_id INT,
    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE SET NULL
);

--  Tabela de Horários
CREATE TABLE horarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    curso_id INT,
    ano INT,
    disciplina VARCHAR(100),
    dia VARCHAR(20),
    sala VARCHAR(20),
    hora_inicio TIME,
    hora_fim TIME,
    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE
);

--  Tabela de Alertas
CREATE TABLE alertas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    mensagem TEXT,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO cursos (nome) VALUES ('Engenharia Informática'), ('Design Multimédia');

INSERT INTO utilizadores (nome, email, senha, cargo, curso_id) 
VALUES ('Admin IPConnect', 'admin@gmail.com', '1234', 'admin', 1);

INSERT INTO horarios (curso_id, ano, disciplina, dia, sala, hora_inicio, hora_fim) 
VALUES (1, 1, 'Sistemas Operativos', 'Quinta', 'L2.1', '14:30', '16:30');